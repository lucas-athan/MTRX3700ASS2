### How to setup.

All you need to do is copy&paste your solution code from Lessons 3 and 4:
* `async_fifo.v`           (Lesson 4)
* `fft_find_peak.sv`       (Lesson 4)
* `fft_input_buffer.sv`    (Lesson 4)
* `fft_mag_sq.sv`          (Lesson 4)
* `low_pass_conv.sv`       (Lesson 4) (For decimation filter)
* `mic/mic_load.sv`        (Lesson 3)
* `mic/i2c_master.sv`      (Lesson 3)
